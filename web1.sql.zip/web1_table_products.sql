
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `products`
--

INSERT INTO `products` (`id`, `user_id`, `product_name`, `quantity`) VALUES
(1, 1, 'Fehérje por 1 kg kiszerelés', 5),
(2, 1, 'Breef Protein', 1),
(3, 1, 'Energy drink', 2147483647),
(4, 1, 'Sport szelet', 2147483647);
